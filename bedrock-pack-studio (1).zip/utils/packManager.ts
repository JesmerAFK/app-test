import JSZip from 'jszip';
import type { PackConfig, Manifest, GeneratedTexture } from '../types';

export function generateManifest(config: PackConfig): Manifest {
  const headerUUID = crypto.randomUUID();
  const dataModuleUUID = crypto.randomUUID();
  const scriptModuleUUID = crypto.randomUUID();

  return {
    format_version: 2,
    header: {
      name: `${config.name} [BP]`,
      description: config.description,
      uuid: headerUUID,
      version: config.version,
      min_engine_version: config.minEngineVersion,
    },
    modules: [
      {
        type: 'data',
        uuid: dataModuleUUID,
        version: config.version,
      },
      {
        type: 'script',
        uuid: scriptModuleUUID,
        version: config.version,
        entry: 'scripts/main.js',
      },
    ],
    dependencies: config.dependencies,
    metadata: {
      authors: [config.author],
    },
  };
}

export async function downloadPack(manifest: Manifest, scriptContent: string, textures: GeneratedTexture[]): Promise<void> {
    const zip = new JSZip();

    zip.file('manifest.json', JSON.stringify(manifest, null, 2));
    zip.file('scripts/main.js', scriptContent);
  
    const packIcon = textures.find(t => t.name === 'pack_icon');
    const itemTextures = textures.filter(t => t.name !== 'pack_icon');
  
    if (packIcon) {
      zip.file('pack_icon.png', packIcon.base64, { base64: true });
    }
  
    const texturesFolder = zip.folder('textures');
    if (texturesFolder) {
      if (itemTextures.length === 0) {
        // Create an empty textures folder if no item textures exist
        texturesFolder.file('.placeholder', '');
      } else {
        for (const texture of itemTextures) {
          texturesFolder.file(`${texture.name}.png`, texture.base64, { base64: true });
        }
      }
    }
    
    const content = await zip.generateAsync({ type: 'blob' });
    const packName = manifest.header.name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(content);
    link.download = `${packName}.mcpack`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}

export const parseVersionString = (version: string): [number, number, number] => {
  const parts = version.split('.').map(Number);
  if (parts.length !== 3 || parts.some(isNaN)) {
    return [1, 0, 0];
  }
  return [parts[0], parts[1], parts[2]];
};

export const formatVersionArray = (version: [number, number, number]): string => {
  return version.join('.');
};