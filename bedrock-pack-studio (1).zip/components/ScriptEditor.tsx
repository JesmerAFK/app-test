import React, { useState, useCallback } from 'react';
import { generateScript, checkScript } from '../services/geminiService';
import { Button } from './ui/Button';

interface ScriptEditorProps {
  scriptContent: string;
  setScriptContent: (content: string) => void;
}

const LoadingIcon = ({ className = "h-5 w-5" }: {className?: string}) => (
    <svg className={`animate-spin text-white ${className}`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const SendIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
    </svg>
);


export const ScriptEditor: React.FC<ScriptEditorProps> = ({ scriptContent, setScriptContent }) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<string | null>(null);

  const handleGenerateScript = useCallback(async () => {
    if (!prompt || isLoading) return;
    setIsLoading(true);
    try {
      const newScript = await generateScript(prompt, scriptContent);
      setScriptContent(newScript);
    } catch (error) {
      console.error("Failed to generate script:", error);
    } finally {
      setIsLoading(false);
      setPrompt('');
    }
  }, [prompt, isLoading, scriptContent, setScriptContent]);

  const handleCheckScript = useCallback(async () => {
    setIsChecking(true);
    setCheckResult(null);
    try {
      const result = await checkScript(scriptContent);
      setCheckResult(result);
    } catch (error) {
      console.error("Failed to check script:", error);
      setCheckResult("An error occurred while communicating with the AI checker.");
    } finally {
      setIsChecking(false);
    }
  }, [scriptContent]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleGenerateScript();
    }
  };

  return (
    <div className="flex flex-col h-full bg-background p-4 gap-4">
      <div className="flex-1 flex flex-col gap-4 overflow-hidden">
        <div className="flex-1 flex flex-col relative rounded-lg border border-subtle bg-surface">
          <div className="absolute top-2 right-2 text-xs text-muted font-mono bg-background px-2 py-1 rounded">scripts/main.js</div>
          <textarea
            value={scriptContent}
            onChange={(e) => setScriptContent(e.target.value)}
            className="w-full flex-1 p-4 bg-transparent font-mono text-gray-300 resize-none focus:outline-none rounded-lg"
            placeholder="Your script code will appear here..."
          />
        </div>
        <div className="h-auto flex flex-col gap-2">
           <div className="flex items-center space-x-2 text-sm text-primary">
              <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M15.405 2.138a.75.75 0 01.638.92l-2.033 6.1a.75.75 0 01-1.33.001l-.85-2.55a.75.75 0 00-.4-1.033L5.28 2.97a.75.75 0 01.597-1.373l8.5 1.7a.75.75 0 011.028.841zM3.75 9.19L6.5 6.94l-2.75-2.25v4.5zM12.5 15.25a.75.75 0 01.75-.75h.008a.75.75 0 01.75.75v.008a.75.75 0 01-.75.75h-.008a.75.75 0 01-.75-.75v-.008zM15.25 12.5a.75.75 0 00-.75.75v.008c0 .414.336.75.75.75h.008a.75.75 0 00.75-.75v-.008a.75.75 0 00-.75-.75h-.008zM12.5 11.25a.75.75 0 01.75-.75h.008a.75.75 0 01.75.75v.008a.75.75 0 01-.75.75h-.008a.75.75 0 01-.75-.75v-.008zM9.75 15.25a.75.75 0 00-.75.75v.008c0 .414.336.75.75.75h.008a.75.75 0 00.75-.75v-.008a.75.75 0 00-.75-.75h-.008z" clipRule="evenodd" /></svg>
              <p className="font-semibold">AI Assistant</p>
           </div>
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Tell the AI what to code... e.g., 'Make players invincible when they join'"
              className="w-full p-3 pr-12 text-gray-300 bg-surface border border-subtle rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              rows={2}
            />
            <button
              onClick={handleGenerateScript}
              disabled={isLoading || !prompt}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-primary text-white hover:bg-primary-hover disabled:bg-muted disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? <LoadingIcon/> : <SendIcon/>}
            </button>
          </div>
        </div>
      </div>
      <div className="h-56 flex flex-col bg-surface border border-subtle rounded-lg p-3 gap-2">
        <div className="flex justify-between items-center">
            <h3 className="font-semibold text-gray-200">Output & Debug</h3>
            <Button onClick={handleCheckScript} disabled={isChecking} className="!py-1.5 !px-3 !text-sm">
                {isChecking && <LoadingIcon className="h-4 w-4 mr-2" />}
                {isChecking ? 'Checking...' : 'Check Script'}
            </Button>
        </div>
        <div className="flex-1 bg-background rounded p-2 overflow-y-auto font-mono text-sm">
            {isChecking && <div className="flex items-center justify-center h-full text-muted"><LoadingIcon className="h-6 w-6"/></div>}
            {!isChecking && checkResult && (
                <pre className={`whitespace-pre-wrap ${checkResult === 'No issues found.' ? 'text-green-400' : 'text-yellow-300'}`}>
                    {checkResult}
                </pre>
            )}
            {!isChecking && !checkResult && (
                <p className="text-muted text-center h-full flex items-center justify-center">Click "Check Script" to analyze your code for errors.</p>
            )}
        </div>
      </div>
    </div>
  );
};