import React, { useState, useCallback } from 'react';
import { PackConfigurator } from './components/PackConfigurator';
import { ScriptEditor } from './components/ScriptEditor';
import { TextureGenerator } from './components/TextureGenerator';
import { generateManifest, downloadPack } from './utils/packManager';
import type { PackConfig, GeneratedTexture } from './types';

const TABS = {
  SCRIPT_EDITOR: 'Script Editor',
  TEXTURE_GENERATOR: 'Pack Icon',
};

export default function App(): React.ReactElement {
  const [activeTab, setActiveTab] = useState<string>(TABS.SCRIPT_EDITOR);
  const [packConfig, setPackConfig] = useState<PackConfig>({
    name: 'My Awesome Pack',
    description: 'A new pack created with Bedrock Pack Studio.',
    author: 'Player',
    version: [1, 0, 0],
    minEngineVersion: [1, 21, 0],
    dependencies: [
      { module_name: '@minecraft/server', version: '2.4.0-beta' },
      { module_name: '@minecraft/server-ui', version: '2.1.0-beta' },
    ],
  });
  const [scriptContent, setScriptContent] = useState<string>(
    `// Generated with Bedrock Pack Studio\nimport { world } from '@minecraft/server';\n\nworld.beforeEvents.chatSend.subscribe((eventData) => {\n  const player = eventData.sender;\n  if (eventData.message.toLowerCase() === 'hello') {\n    player.sendMessage('Hello from your new pack!');\n    eventData.cancel = true;\n  }\n});\n`
  );
  const [packIcon, setPackIcon] = useState<GeneratedTexture | null>(null);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  const handleDownload = useCallback(async () => {
    setIsDownloading(true);
    try {
      const manifest = generateManifest(packConfig);
      const textures = packIcon ? [packIcon] : [];
      await downloadPack(manifest, scriptContent, textures);
    } catch (error) {
      console.error("Failed to download pack:", error);
      alert("An error occurred while creating the pack. Check the console for details.");
    } finally {
      setIsDownloading(false);
    }
  }, [packConfig, scriptContent, packIcon]);
  
  const renderActiveTab = () => {
    switch (activeTab) {
      case TABS.SCRIPT_EDITOR:
        return <ScriptEditor scriptContent={scriptContent} setScriptContent={setScriptContent} />;
      case TABS.TEXTURE_GENERATOR:
        return <TextureGenerator packIcon={packIcon} setPackIcon={setPackIcon} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="bg-surface p-4 shadow-lg flex justify-between items-center z-10">
        <div className="flex items-center space-x-3">
          <svg className="w-8 h-8 text-primary" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 16.5C21 16.5 20 17.5 16 17.5C13 17.5 12 16.5 12 16.5C12 16.5 12 15.5 15 15.5C18 15.5 21 16.5 21 16.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M12 12.5C12 12.5 11 13.5 7 13.5C4 13.5 3 12.5 3 12.5C3 12.5 3 11.5 6 11.5C9 11.5 12 12.5 12 12.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M16.5 21C16.5 21 17.5 20 17.5 16C17.5 13 16.5 12 16.5 12C16.5 12 15.5 12 15.5 15C15.5 18 16.5 21 16.5 21Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M12.5 12C12.5 12 13.5 11 13.5 7C13.5 4 12.5 3 12.5 3C12.5 3 11.5 3 11.5 6C11.5 9 12.5 12 12.5 12Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M7.5 21C7.5 21 8.5 20 8.5 16C8.5 13 7.5 12 7.5 12C7.5 12 6.5 12 6.5 15C6.5 18 7.5 21 7.5 21Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M3 16.5C3 16.5 4 17.5 8 17.5C11 17.5 12 16.5 12 16.5C12 16.5 12 15.5 9 15.5C6 15.5 3 16.5 3 16.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <h1 className="text-2xl font-bold text-white">Bedrock Pack Studio</h1>
        </div>
        <div className="flex items-center space-x-2">
            <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="bg-primary text-white font-bold py-2 px-6 rounded-lg hover:bg-primary-hover transition-colors disabled:bg-muted disabled:cursor-not-allowed flex items-center space-x-2"
            >
            {isDownloading ? (
                <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
            ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
            )}
            <span>{isDownloading ? 'Packaging...' : 'Download'}</span>
            </button>
        </div>
      </header>

      <main className="flex-grow flex flex-col md:flex-row h-full overflow-hidden">
        <aside className="w-full md:w-72 lg:w-80 bg-surface p-4 border-r border-subtle overflow-y-auto">
          <PackConfigurator config={packConfig} setConfig={setPackConfig} />
        </aside>
        
        <div className="flex-1 flex flex-col bg-background">
          <nav className="flex space-x-1 border-b border-subtle bg-surface px-4">
            {Object.values(TABS).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-3 px-4 font-semibold transition-colors ${
                  activeTab === tab 
                    ? 'text-primary border-b-2 border-primary' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </nav>
          <div className="flex-1 overflow-y-auto">
            {renderActiveTab()}
          </div>
        </div>
      </main>
    </div>
  );
}